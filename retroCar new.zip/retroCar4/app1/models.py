from django.db import models

# Create your models here.
class tbl_owner(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    place=models.CharField(max_length=30)
    phone=models.IntegerField()
    email=models.CharField(max_length=30)
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    class Meta:
        db_table="tbl_owner"

class tbl_car(models.Model):
    owner_id=models.CharField(max_length=30)
    car_name=models.CharField(max_length=30)
    features=models.CharField(max_length=30)
    price=models.IntegerField()
    image=models.FileField()
    class Meta:
        db_table="tbl_car"

class tbl_order(models.Model):
    user_id=models.CharField(max_length=100)
    car_id=models.IntegerField()
    car_name=models.CharField(max_length=30)
    price=models.IntegerField()
    status=models.CharField(max_length=30)
    class Meta:
        db_table="tbl_order"

class tbl_payment(models.Model):
    order_id=models.IntegerField()
    user_id=models.CharField(max_length=30)
    
    amount=models.IntegerField()
    status=models.CharField(max_length=30)
    class Meta:
        db_table="tbl_payment"

class tbl_user(models.Model):
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    place=models.CharField(max_length=30)
    phone=models.IntegerField()
    email=models.CharField(max_length=30)
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    class Meta:
        db_table="tbl_user"

