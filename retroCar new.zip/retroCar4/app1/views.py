from django.shortcuts import render,redirect
from app1.models import tbl_owner,tbl_order,tbl_car,tbl_payment,tbl_user
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import logout
import os

# Create your views here.
def index(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')

# def owner(request):
#     return render(request,'owner.html')

def ownerHome(request):
    return render(request,'ownerHome.html')

def ownerReg(request):
    if request.method=='POST':
        a=request.POST['fname']
        b=request.POST['lname']
        c=request.POST['place']
        d=request.POST['phn']
        e=request.POST['email']
        f=request.POST['uname']
        g=request.POST['pswd']
        q=tbl_owner(firstname=a,lastname=b,place=c,phone=d,email=e,username=f,password=g)
        data=User(username=f)
        data.set_password(g)
        data.save()
        q.save()
        return HttpResponse('<script>alert("successfully registered"),window.location="/ownerLogin";</script>')
    return render(request,'ownerReg.html')

def ownerLogin(request):
    if request.method=="POST":
        u=request.POST["uname"]
        v=request.POST["pswd"]
        au=authenticate(username=u,password=v)
        request.session["user_id"]=u
        if au is not None and au.is_superuser==0:
            return render(request,"ownerHome.html")
    return render(request,'ownerLogin.html')

def viewOwner(request):
    q=tbl_owner.objects.all()
    return render(request,'viewOwner.html',{'x':q})

def carReg(request):
    oid=request.session['user_id']
    if request.method=='POST':
        b=request.POST["carname"]
        c=request.POST["fea"]
        d=request.POST["pri"]
        e=request.FILES["image"]
        q=tbl_car(owner_id=oid,car_name=b,features=c,price=d,image=e)
        q.save()
        return HttpResponse('<script>alert("successfully added"),window.location="/ownerHome";</script>')
    return render(request,'carReg.html')

def viewCarAdmin(request):
    q=tbl_car.objects.all()
    return render(request,'viewCarAdmin.html',{'y':q})

def viewCarUser(request):
    q=tbl_car.objects.all()
    return render(request,'viewCarUser.html',{'y':q})


def upDate(request,id):
    q=tbl_car.objects.get(id=id)
    if request.method=="POST":
        q.car_name=request.POST['carname']
        q.features=request.POST['features']
        q.price=request.POST['price']
        if len(request.FILES)!=0:
            if len(q.image.url)>0:
                os.remove(q.image.path)
                q.image=request.FILES['image']
        q.save()
        return HttpResponse('<script>alert("Successfully Updated"),window.location="/viewCarOwner";</script>')
    return render(request,'viewCarOwner.html',{'x':q})

def delete(request,id):
    q=tbl_car.objects.get(id=id)
    q.delete()
    return HttpResponse('<script>alert("Deleted successfully"),window.location="/viewCarOwner";</script>')

def user(request):
    return render(request,'user.html')

def userReg(request):
    if request.method=='POST':
        a=request.POST['fname']
        b=request.POST['lname']
        c=request.POST['place']
        d=request.POST['phn']
        e=request.POST['email']
        f=request.POST['uname']
        g=request.POST['pswd']
        q=tbl_user(firstname=a,lastname=b,place=c,phone=d,email=e,username=f,password=g)
        data=User(username=f)
        data.set_password(g)
        data.save()
        q.save()
        return HttpResponse('<script>alert("successfully registered"),window.location="/userLogin";</script>')
    return render(request,'userReg.html')

def userHome(request):
    return render(request,'userHome.html')

def viewUser(request):
    q=tbl_user.objects.all()
    return render(request,'viewUser.html',{'x':q})

def userLogin(request):
    if request.method=="POST":
        u=request.POST["uname"]
        v=request.POST["pswd"]
        au=authenticate(username=u,password=v)
        request.session["user_id"]=u
        if au is not None and au.is_superuser==0:
            return render(request,"userHome.html")
    return render(request,'userLogin.html')

def orderReg(request,id,price):
    uid=request.session['user_id']
    cid=id
    pr=price
    q=tbl_car.objects.get(id=cid)
    cname=q.car_name
    q1=tbl_order(user_id=uid,car_id=cid,car_name=cname,price=pr,status='pending')  
    q1.save()
    return HttpResponse('<script>alert("Order success"),window.location="/userHome";</script>')
    
def viewOrderUser(request):
    uid=request.session['user_id']
    q=tbl_order.objects.filter(user_id=uid)
    return render(request,'viewOrderUser.html',{'x':q})

def viewCarOwner(request):
    id=request.session['user_id']
    c=tbl_car.objects.filter(owner_id=id)
    return render(request,'viewCarOwner.html',{'y':c})

def viewOrderOwner(request):
    id=request.session['user_id']
    c=tbl_car.objects.filter(owner_id=id)
    for i in c:
        cid=i.id
        print(cid)
    q=tbl_order.objects.filter(car_id=cid)
    return render(request,'viewOrderOwner.html',{'x':q})

def viewOrderAdmin(request):
    q=tbl_order.objects.all()
    return render(request,'viewOrderAdmin.html',{'x':q})



def payReg(request,id,p):
    uid=request.session['user_id']
    oid=id
    price=p
    if request.method=='POST':
        amt=request.POST['amount']
        q=tbl_payment(order_id=oid,user_id=uid,amount=amt,status="Paid")
        q.save()
        o=tbl_order.objects.get(id=oid)
        o.status="Paid"
        o.save()
        return HttpResponse('<script>alert("Payment Successfully"),window.location="/userHome";</script>')
    return render(request,'payReg.html',{'pr':price})

def viewPay(request):
    q=tbl_payment.objects.all()
    return render(request,'viewPayment.html',{'x':q})

def adminLogin(request):
    if request.method=="POST":
        u=request.POST["uname"]
        v=request.POST["pswd"]
        au=authenticate(username=u,password=v)
        request.session["username"]=u
        if au is not None and au.is_superuser==1:
            return render(request,"adminHome.html")
        elif au is not None and au.is_superuser==0:
            return render(request,'adminHome.html')
        else:
            return HttpResponse('Invalid User')
    return render(request,'adminLogin.html')

def order_approval(request,id):
    oid=id
    q=tbl_order.objects.get(id=oid)
    q.status="Approved"
    q.save()
    return HttpResponse('<script>alert("Successfully Approved"),window.location="/viewOrderOwner";</script>')

def order_rejection(request,id):
    oid=id
    q=tbl_order.objects.get(id=oid)
    q.status="Rejected"
    q.save()
    return HttpResponse('<script>alert("Successfully Rejected"),window.location="/viewOrderOwner";</script>')

def logOut(request):
    logout(request)
    return redirect('/')
        




    
