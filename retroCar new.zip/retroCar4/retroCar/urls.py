"""
URL configuration for retroCar project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app1 import views
from django.conf.urls.static import static
from django.conf import settings
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    path('home/',views.home),
    path('ownerReg/',views.ownerReg),
    path('viewOwner/',views.viewOwner),
    path('ownerLogin/',views.ownerLogin),
    path('ownerHome/',views.ownerHome),
    path('user/',views.user), 
    path('userHome/',views.userHome),
    path('userReg/',views.userReg),
    path('viewUser/',views.viewUser),
    path('userLogin/',views.userLogin),
    path('carReg/',views.carReg),
    path('viewCarAdmin/',views.viewCarAdmin),
    path('viewCarUser/',views.viewCarUser),
    path('viewCarOwner/',views.viewCarOwner),
    path('addCar/',views.carReg),
    path('orderreg/<id>/<price>',views.orderReg),
    path('viewOrderUser/',views.viewOrderUser),
    path('viewOrderOwner/',views.viewOrderOwner),
    path('viewOrderAdmin/',views.viewOrderAdmin),
    path('payReg/<id>/<p>',views.payReg),
    path('viewPay/',views.viewPay),
    path('adminLogin/',views.adminLogin),
    path('upDate/<int:id>',views.upDate),
    path('delete/<int:id>',views.delete),
    path('login/',views.adminLogin),
    path('order_approval/<id>',views.order_approval),
    path('order_rejection/<id>',views.order_rejection),
    path('logOut/',views.logOut),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)